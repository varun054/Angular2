export default function(){
    return [
        {
            title: 'Javascript: Complete Reference',
            pages: 340
        },
        {
            title: 'You can win' ,
            pages: 340
        },
        {
            title: 'Geeta' ,
            pages: 340
        },
        {
            title: 'Ramayana',
            pages: 340 
        },
        {
            title: 'Godan' ,
            pages: 340
        }
    ]
}

